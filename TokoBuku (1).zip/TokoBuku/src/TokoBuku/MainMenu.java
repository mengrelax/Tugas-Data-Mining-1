package TokoBuku;

public class MainMenu extends Login{
    
    public static void main(String[] args) {
        // buat jalankan class Login
        Login login = new Login();
        login.setVisible(true);
    }
}
