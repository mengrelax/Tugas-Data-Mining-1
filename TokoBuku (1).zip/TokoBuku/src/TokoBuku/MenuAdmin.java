package TokoBuku;

import Database.KoneksiSQL;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import User.Admin;
import javax.swing.table.DefaultTableModel;

public class MenuAdmin extends javax.swing.JFrame implements Admin {
    private void clsform(){
        // kosongkan form otomatis
        txtKdbuku.setText("");
        txtKdbaru.setText("");
        txtJudul.setText("");
        txtPengarang.setText("");
        txtPenerbit.setText("");
        txtThnterbit.setText("");
        txtHarga.setText("");
        txtStok.setText("");
    }
    public MenuAdmin() {
        
        initComponents();
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
        
        // panggil function untuk tampilkan data buku
        tampilkandata();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtJudul = new javax.swing.JTextField();
        txtPengarang = new javax.swing.JTextField();
        txtPenerbit = new javax.swing.JTextField();
        txtThnterbit = new javax.swing.JTextField();
        txtHarga = new javax.swing.JTextField();
        txtStok = new javax.swing.JTextField();
        btnSimpanData = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        btnBatal = new javax.swing.JButton();
        btnUbah = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        txtKdbuku = new javax.swing.JTextField();
        btnHapus = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBuku = new javax.swing.JTable();
        btnKembali = new javax.swing.JButton();
        btnCari = new javax.swing.JButton();
        txtCaribuku = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtKdbaru = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(67, 193, 158));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DATA TOKO BUKU TOGAMAS");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Tahun Terbit");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 230, 80, 30));

        txtJudul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJudulActionPerformed(evt);
            }
        });
        jPanel1.add(txtJudul, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 340, 210, 30));

        txtPengarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPengarangActionPerformed(evt);
            }
        });
        jPanel1.add(txtPengarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 210, 30));
        jPanel1.add(txtPenerbit, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, 210, 30));
        jPanel1.add(txtThnterbit, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, 210, 30));

        txtHarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHargaActionPerformed(evt);
            }
        });
        jPanel1.add(txtHarga, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 340, 210, 30));

        txtStok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStokActionPerformed(evt);
            }
        });
        jPanel1.add(txtStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 420, 210, 30));

        btnSimpanData.setBackground(new java.awt.Color(0, 153, 204));
        btnSimpanData.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSimpanData.setForeground(new java.awt.Color(255, 255, 255));
        btnSimpanData.setText("Simpan");
        btnSimpanData.setBorder(null);
        btnSimpanData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSimpanDataMouseClicked(evt);
            }
        });
        btnSimpanData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanDataActionPerformed(evt);
            }
        });
        jPanel1.add(btnSimpanData, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 490, 120, 30));

        btnKeluar.setBackground(new java.awt.Color(255, 102, 102));
        btnKeluar.setForeground(new java.awt.Color(255, 255, 255));
        btnKeluar.setText("Keluar");
        btnKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKeluarActionPerformed(evt);
            }
        });
        jPanel1.add(btnKeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 560, -1, -1));

        btnBatal.setBackground(new java.awt.Color(255, 102, 102));
        btnBatal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBatal.setForeground(new java.awt.Color(255, 255, 255));
        btnBatal.setText("Batal");
        btnBatal.setBorder(null);
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });
        jPanel1.add(btnBatal, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 490, 80, 30));

        btnUbah.setBackground(new java.awt.Color(0, 153, 204));
        btnUbah.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUbah.setForeground(new java.awt.Color(255, 255, 255));
        btnUbah.setText("Ubah");
        btnUbah.setBorder(null);
        btnUbah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUbahActionPerformed(evt);
            }
        });
        jPanel1.add(btnUbah, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 490, 120, 30));

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, 110, -1));

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));
        jPanel5.setForeground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, 110, -1));

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel7.setForeground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 320, 110, -1));

        jPanel8.setBackground(new java.awt.Color(204, 204, 255));
        jPanel8.setForeground(new java.awt.Color(255, 255, 255));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 110, -1));

        txtKdbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKdbukuActionPerformed(evt);
            }
        });
        jPanel1.add(txtKdbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 210, 30));

        btnHapus.setBackground(new java.awt.Color(255, 102, 102));
        btnHapus.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnHapus.setForeground(new java.awt.Color(255, 255, 255));
        btnHapus.setText("Hapus");
        btnHapus.setBorder(null);
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });
        jPanel1.add(btnHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 490, 80, 30));

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));
        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(255, 255, 255), null, null));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel9.setText("Data Buku");
        jPanel9.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 70, 30));

        jPanel1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, 460, 30));

        tblBuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Kode Buku", "Judul Buku", "Pengarang", "Penerbit", "Tahun Terbit", "Harga Jual", "Stok"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblBuku.setColumnSelectionAllowed(true);
        tblBuku.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBukuMouseClicked(evt);
            }
        });
        tblBuku.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tblBukuKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tblBukuKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tblBuku);
        tblBuku.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        jScrollPane2.setViewportView(jScrollPane1);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, 460, 320));

        btnKembali.setBackground(new java.awt.Color(255, 102, 102));
        btnKembali.setForeground(new java.awt.Color(255, 255, 255));
        btnKembali.setText("Kembali");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });
        jPanel1.add(btnKembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 560, -1, -1));

        btnCari.setBackground(new java.awt.Color(0, 153, 204));
        btnCari.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari.setForeground(new java.awt.Color(255, 255, 255));
        btnCari.setText("Cari Buku");
        btnCari.setBorder(null);
        btnCari.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCariMouseClicked(evt);
            }
        });
        btnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCariActionPerformed(evt);
            }
        });
        jPanel1.add(btnCari, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 130, 80, 30));

        txtCaribuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCaribukuActionPerformed(evt);
            }
        });
        jPanel1.add(txtCaribuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 130, 200, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Kode Buku Baru");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Judul Buku");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, -1, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Pengarang");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 390, -1, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Penerbit");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 50, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Harga Jual");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 310, -1, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Stok Buku");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 390, -1, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("FORM EDIT BUKU");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\Yoga6\\Downloads\\gradasi biruu.jpg")); // NOI18N
        jLabel10.setText("jLabel10");
        jLabel10.setPreferredSize(new java.awt.Dimension(150, 550));
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 0, 160, 620));
        jPanel1.add(txtKdbaru, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 210, 30));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Kode Buku");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\Yoga6\\Downloads\\gradasi biru.jpg")); // NOI18N
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 620));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtKdbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKdbukuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtKdbukuActionPerformed

    private void btnUbahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUbahActionPerformed
        ubahbuku();
    }//GEN-LAST:event_btnUbahActionPerformed

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        clsform();
    }//GEN-LAST:event_btnBatalActionPerformed

    private void btnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeluarActionPerformed
        this.dispose();
        JOptionPane.showMessageDialog(null, "Anda keluar dari aplikasi!");
        System.exit(0);
    }//GEN-LAST:event_btnKeluarActionPerformed

    private void btnSimpanDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSimpanDataMouseClicked
        tambahbuku();
    }//GEN-LAST:event_btnSimpanDataMouseClicked

    private void txtStokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStokActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStokActionPerformed

    private void txtHargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHargaActionPerformed

    private void txtPengarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPengarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPengarangActionPerformed

    private void txtJudulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJudulActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtJudulActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        hapusbuku();
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        this.dispose();
        Login kembali = new Login();
        kembali.setVisible(true);
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void txtCaribukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCaribukuActionPerformed
        
    }//GEN-LAST:event_txtCaribukuActionPerformed

    private void tblBukuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBukuMouseClicked
        // buat input data yang ada ditabel secara otomatis
        int baris = tblBuku.rowAtPoint(evt.getPoint());
        String kodebuku = tblBuku.getValueAt(baris, 1).toString();
        txtKdbuku.setText(kodebuku);
        String judul = tblBuku.getValueAt(baris, 2).toString();
        txtJudul.setText(judul);
        String pengarang = tblBuku.getValueAt(baris, 3).toString();
        txtPengarang.setText(pengarang);
        String penerbit = tblBuku.getValueAt(baris, 4).toString();
        txtPenerbit.setText(penerbit);
        String thnterbit = tblBuku.getValueAt(baris, 5).toString();
        txtThnterbit.setText(thnterbit);
        String harga = tblBuku.getValueAt(baris, 6).toString();
        txtHarga.setText(harga);
        String stok = tblBuku.getValueAt(baris, 7).toString();
        txtStok.setText(stok);
    }//GEN-LAST:event_tblBukuMouseClicked

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
        
    }//GEN-LAST:event_btnCariActionPerformed

    private void btnCariMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCariMouseClicked
        caribuku();
    }//GEN-LAST:event_btnCariMouseClicked

    private void btnSimpanDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSimpanDataActionPerformed

    private void tblBukuKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblBukuKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_tblBukuKeyPressed

    private void tblBukuKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblBukuKeyReleased
        
    }//GEN-LAST:event_tblBukuKeyReleased

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnCari;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnSimpanData;
    private javax.swing.JButton btnUbah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblBuku;
    private javax.swing.JTextField txtCaribuku;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtJudul;
    private javax.swing.JTextField txtKdbaru;
    private javax.swing.JTextField txtKdbuku;
    private javax.swing.JTextField txtPenerbit;
    private javax.swing.JTextField txtPengarang;
    private javax.swing.JTextField txtStok;
    private javax.swing.JTextField txtThnterbit;
    // End of variables declaration//GEN-END:variables

    @Override
    public void tambahbuku() {
        try{
           String sql = "INSERT INTO buku VALUES('"
                   +txtKdbuku.getText()+"','"
                   +txtJudul.getText()+"','"
                   +txtPengarang.getText()+"','"
                   +txtPenerbit.getText()+"','"
                   +txtThnterbit.getText()+"','"
                   +txtHarga.getText()+"','"
                   +txtStok.getText()+"');";
           java.sql.Connection con = (Connection) KoneksiSQL.connect();
           java.sql.Statement stm = con.createStatement();
           java.sql.PreparedStatement pstm = con.prepareStatement(sql);
           pstm.execute();
           JOptionPane.showMessageDialog(null, "Buku telah ditambahkan!");
           tampilkandata();
           clsform();
       }
       catch (SQLException e){
           JOptionPane.showMessageDialog(this, "Tambah buku gagal!");
           JOptionPane.showMessageDialog(this, e.getMessage());
       }
    }
    
    @Override
    public void tampilkandata(){
        // bikin tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nomor");
        model.addColumn("Kode Buku");
        model.addColumn("Judul Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Harga Jual");
        model.addColumn("Stok");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM buku";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql);
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getString(6), rst.getString(7)});
            }
            tblBuku.setModel(model);
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }
    
    @Override
    public void caribuku(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nomor");
        model.addColumn("Kode Buku");
        model.addColumn("Judul Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Harga");
        model.addColumn("Stok");
        
        try{
            int no = 1;
            String sql = "SELECT*FROM buku WHERE kode_buku like '%"+txtCaribuku.getText()
                    +"%'or judul_buku like '%"+txtCaribuku.getText()+"%'"
                    + "or pengarang like '%"+txtCaribuku.getText()+"%'"
                    + "or penerbit like '%"+txtCaribuku.getText()+"%'"
                    + "or tahun_terbit like '%"+txtCaribuku.getText()+"%'"
                    + "or harga_jual like '%"+txtCaribuku.getText()+"%'";
                    
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.ResultSet rst = stm.executeQuery(sql);
            
            while (rst.next()){
                // bikin baris
                model.addRow(new Object[] {no++, rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getString(6), rst.getString(7)});
            }
            tblBuku.setModel(model);
        }
        catch (SQLException e){
            System.out.println("Error" + e.getMessage());
        }
    }
    
    @Override
    public void ubahbuku(){
        try{
            String sql = "UPDATE buku SET kode_buku='"+txtKdbuku.getText()
                    +"', kode_buku='" + txtKdbaru.getText()
                    +"', judul_buku='" + txtJudul.getText()
                    +"', pengarang='" + txtPengarang.getText()
                    +"', penerbit='" + txtPenerbit.getText()
                    +"', tahun_terbit='" + txtThnterbit.getText()
                    +"', harga_jual='" + txtHarga.getText()
                    +"', stok_buku='" + txtStok.getText()
                    + "' WHERE kode_buku = '" + txtKdbuku.getText() + "'";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data buku telah diubah!");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkandata();
        clsform();            
    }
    
    @Override
    public void hapusbuku(){
        try{
            String sql = "DELETE FROM buku WHERE kode_buku='"+txtKdbuku.getText()
                    + "'";
            java.sql.Connection con = (Connection) KoneksiSQL.connect();
            java.sql.Statement stm = con.createStatement();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data buku telah dihapus!");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkandata();
        clsform();              
    }
}
