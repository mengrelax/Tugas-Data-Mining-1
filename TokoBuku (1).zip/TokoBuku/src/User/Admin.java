package User;

//interface Admin untuk class yang membutuhkan atau melibatkan crud

public interface Admin {
    public void tambahbuku();
    public void hapusbuku();
    public void tampilkandata();
    public void caribuku();
    public void ubahbuku();
}
