package User;

//interface User untuk class yang membutuhkan atau melibatkan proses transaksi

public interface User {
    public void tampilkandata();
    public void caribuku();
    public void bayar();
}
