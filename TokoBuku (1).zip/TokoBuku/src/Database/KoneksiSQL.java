package Database;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;

public class KoneksiSQL {
    static Connection con;
    static Statement stmt;
    static final String DB_URL = "jdbc:mysql://localhost/tokobuku"; //ke database mysql
    static String username = "root";
    static String password = "";

    public static Connection connect(){ //fungsi
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //manggil yang ada di library
            con = DriverManager.getConnection(DB_URL,username,password); //untuk nampung koneksi database
            stmt = con.createStatement(); //eksekusi localhost
            System.out.println("Koneksi Berhasil");
            
        } catch (Exception e) {
            System.out.println("Koneksi Gagal");
//            e.printStackTrace();
        }
        return con;
    }
    
    public static void main(String[] args) {
        connect(); //dipanggil
    }
    
}
